//
//  ContentView.swift
//  Multiply
//
//  Created by Shaheer Javed on 24/9/2024.
//

import SwiftUI

struct ContentView: View {
    @State private var input: String = ""
    @State private var result: String = ""
    @State private var inputMode: InputMode = .text

    enum InputMode: String, CaseIterable {
        case text = "Text Input"
        case buttons = "Button Input"
    }

    var body: some View {
        VStack {
            Text("Simple Calculator")
                .font(.largeTitle)
                .padding()

            // Picker for input mode selection
            Picker("Input Mode", selection: $inputMode) {
                ForEach(InputMode.allCases, id: \.self) { mode in
                    Text(mode.rawValue).tag(mode)
                }
            }
            .pickerStyle(SegmentedPickerStyle())
            .padding()

            // Input area
            if inputMode == .text {
                TextField("Enter expression", text: $input, onCommit: calculate)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                    .font(.system(size: 30)) // Increased font size
                    .frame(height: 50) // Increased height
                Button(action: calculate) {
                    Text("Calculate")
                        .font(.title)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
                .padding()
            }

            // Display area for input and result
            Text("Input: \(input)")
                .font(.title2)
                .padding()
            Text("Result: \(result)")
                .font(.title2)
                .padding()

            // Button-based input for basic operations
            if inputMode == .buttons {
                VStack {
                    HStack {
                        Button("7") { appendInput("7") }
                        Button("8") { appendInput("8") }
                        Button("9") { appendInput("9") }
                        Button("÷") { appendInput("/") }
                    }
                    .font(.title)
                    .padding()

                    HStack {
                        Button("4") { appendInput("4") }
                        Button("5") { appendInput("5") }
                        Button("6") { appendInput("6") }
                        Button("×") { appendInput("*") }
                    }
                    .font(.title)
                    .padding()

                    HStack {
                        Button("1") { appendInput("1") }
                        Button("2") { appendInput("2") }
                        Button("3") { appendInput("3") }
                        Button("-") { appendInput("-") }
                    }
                    .font(.title)
                    .padding()

                    HStack {
                        Button("C") { clearInput() }
                        Button("0") { appendInput("0") }
                        Button("=") { calculate() }
                        Button("+") { appendInput("+") }
                    }
                    .font(.title)
                    .padding()
                }
            }
        }
        .padding()
        .frame(minWidth: 400, minHeight: 400) // Fixed window size
        .onChange(of: inputMode) { _ in
            // Clear input and result when switching modes
            clearInput()
            result = ""
        }
    }

    // Append input for button clicks
    func appendInput(_ value: String) {
        input += value
    }

    // Clear the input field
    func clearInput() {
        input = ""
        result = ""
    }

    // Calculate the result from the input string
    func calculate() {
        let expression = NSExpression(format: input)
        if let value = expression.expressionValue(with: nil, context: nil) as? NSNumber {
            result = value.stringValue
            input = result // Display result in the input box
        } else {
            result = "Invalid Expression"
        }
    }
}

