//
//  MultiplyApp.swift
//  Multiply
//
//  Created by Shaheer Javed on 24/9/2024.
//

import SwiftUI

@main
struct MultiplyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
