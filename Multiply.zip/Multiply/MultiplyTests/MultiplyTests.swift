//
//  MultiplyTests.swift
//  MultiplyTests
//
//  Created by Shaheer Javed on 24/9/2024.
//

import Testing
@testable import Multiply

struct MultiplyTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
