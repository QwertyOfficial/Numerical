
import SwiftUI

@main
struct NumericalApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
