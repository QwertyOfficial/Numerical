import SwiftUI
import Combine

struct ContentView: View {
    @State private var inputText: String = ""
    @State private var timer: Timer?
    @Environment(\.colorScheme) var colorScheme

    var body: some View {
        VStack {
            TextEditor(text: $inputText)
                .font(.system(size: 16, weight: .regular, design: .monospaced))
                .padding()
                .frame(width: 400, height: 250)
                .background(colorScheme == .dark ? Color.black.opacity(0.8) : Color.white.opacity(0.8))
                .foregroundColor(colorScheme == .dark ? Color.white : Color.black)
                .cornerRadius(8)
                .onChange(of: inputText) { _ in
                    startTypingTimer()
                }
        }
        .padding()
        .frame(width: 420, height: 330)
        .background(colorScheme == .dark ? Color.black : Color.white)
        .onAppear {
            if let window = NSApplication.shared.windows.first {
                window.title = "Numerical"
                window.minSize = NSSize(width: 420, height: 330)
                window.maxSize = NSSize(width: 420, height: 330)
            }
        }
    }

    private func startTypingTimer() {
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: false) { _ in
            processInput()
        }
    }

    private func processInput() {
        let lines = inputText.split(separator: "\n").map { String($0) }
        var processedText = ""

        for line in lines {
            let cleanedLine = line.components(separatedBy: "=").first?.trimmingCharacters(in: .whitespaces) ?? line

            if let solution = evaluateLine(line: cleanedLine) {
                processedText += "\(cleanedLine) = \(solution)\n"
            } else {
                processedText += "\(cleanedLine)\n"
            }
        }

        inputText = processedText
    }

    private func evaluateLine(line: String) -> String? {
        let parts = line.split(separator: "=").map { $0.trimmingCharacters(in: .whitespaces) }

        if parts.count == 2 {
            let leftSide = parts[0]
            let rightSide = parts[1]

            if leftSide.contains("x") {
                return solveForX(leftSide: leftSide, rightSide: rightSide)
            } else {
                return evaluateExpression(expression: rightSide)
            }
        } else {
            return evaluateExpression(expression: line)
        }
    }

    private func evaluateExpression(expression: String) -> String? {
        let exp = NSExpression(format: expression)
        if let result = exp.expressionValue(with: nil, context: nil) as? NSNumber {
            return String(format: "%.2f", result.doubleValue)
        }
        return nil
    }

    private func solveForX(leftSide: String, rightSide: String) -> String? {
        let rightExpression = NSExpression(format: rightSide)

        for x in stride(from: -1000.0, through: 1000.0, by: 0.1) {
            let variables: [String: Any] = ["x": x]
            let leftExpression = NSExpression(format: leftSide.replacingOccurrences(of: "x", with: "\(x)"))

            if let leftValue = leftExpression.expressionValue(with: variables, context: nil) as? Double,
               let rightValue = rightExpression.expressionValue(with: nil, context: nil) as? Double,
               abs(leftValue - rightValue) < 0.01 {
                return String(format: "%.2f", x)
            }
        }

        return nil
    }
}
